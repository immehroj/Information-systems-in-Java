package com.example.projj;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface BookRepository extends JpaRepository<Book, Long> {
    @Query("SELECT b FROM Book b WHERE concat(b.title, ' ', b.publisher, ' ', b.studentName) LIKE %?1%")
    List<Book> search(String keyword);

    @Query("SELECT b FROM Book b ORDER BY b.issueDate ASC")
    List<Book> sortByIssueDateAsc();
    ;
    @Query("SELECT b FROM Book b ORDER BY b.issueDate DESC")
    List<Book> sortByIssueDateDesc();
    @Query("SELECT b FROM Book b ORDER BY b.id")
    List<Book> findAllBooksInOrigin();
    @Query("SELECT b.issueDate, COUNT(b) FROM Book b GROUP BY b.issueDate")
    List<Object[]> getBookIssueStatistics();
}