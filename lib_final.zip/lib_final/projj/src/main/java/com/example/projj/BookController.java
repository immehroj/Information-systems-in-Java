package com.example.projj;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class BookController {

    @Autowired
    private BookService service;

    @RequestMapping("/")
    public String viewHomePage(Model model, @RequestParam(value = "keyword", required = false) String keyword) {
        List<Book> listBooks = service.listAll(keyword);
        model.addAttribute("listBooks", listBooks);
        model.addAttribute("keyword", keyword);

        List<Object[]> stats = service.getBookIssueStatistics();
        List<String> dates = new ArrayList<>();
        List<Long> counts = new ArrayList<>();

        for (Object[] row : stats) {
            dates.add(row[0].toString());
            counts.add((Long) row[1]);
        }

        model.addAttribute("dates", dates);
        model.addAttribute("counts", counts);

        return "index";  // Возвращаем шаблон
    }

    @RequestMapping("/new")
    public String showNewBookForm(Model model) {
        Book book = new Book();
        model.addAttribute("book", book);
        return "new_book";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveBook(@ModelAttribute("book") Book book, BindingResult result) {
        if (result.hasErrors()) {
            return "edit_book";
        }
        service.save(book);
        return "redirect:/";
    }

    @RequestMapping("/edit/{id}")
    public String showEditBookForm(@PathVariable(name = "id") Long id, Model model) {
        Book book = service.get(id);
        model.addAttribute("book", book);
        return "edit_book";
    }

    @RequestMapping("/delete/{id}")
    public String deleteBook(@PathVariable(name = "id") Long id) {
        service.delete(id);
        return "redirect:/";
    }


    @RequestMapping("/sort")
    public String sortByIssueDate(@RequestParam(value = "order", defaultValue = "asc") String order, Model model) {
        List<Book> sortedBooks;

        if (order.equals("asc")) {
            sortedBooks = service.sortByIssueDateAsc();
        } else if (order.equals("desc")) {
            sortedBooks = service.sortByIssueDateDesc();
        } else {
            sortedBooks = service.getAllBooksInOriginalOrder();
        }
        model.addAttribute("listBooks", sortedBooks);
        model.addAttribute("currentOrder", order);

        List<Object[]> stats = service.getBookIssueStatistics();
        List<String> dates = new ArrayList<>();
        List<Long> counts = new ArrayList<>();

        for (Object[] row : stats) {
            dates.add(row[0].toString());
            counts.add((Long) row[1]);
        }

        model.addAttribute("dates", dates);
        model.addAttribute("counts", counts);
        return "index";
    }

}