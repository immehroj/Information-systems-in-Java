package com.example.projj;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Setter
@Entity
public class Book {
    @Id
    private Long id; // Убираем @GeneratedValue
    @Getter
    private String title;
    @Getter
    private String publisher;
    @Getter
    private LocalDate issueDate;
    @Getter
    private String studentName;
    @Getter
    private LocalDate returnDate;

    public Long getId() {
        return id;
    }
}
