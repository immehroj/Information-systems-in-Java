package com.example.projj;

import java.util.PriorityQueue;

public class prrr {
    public static void main(String[] args) {


    }
}
