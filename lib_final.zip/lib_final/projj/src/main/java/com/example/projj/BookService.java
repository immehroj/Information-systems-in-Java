package com.example.projj;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    @Autowired
    private BookRepository repo;

    public List<Book> listAll(String keyword) {
        if (keyword != null) {
            return repo.search(keyword);
        }
        return repo.findAll();
    }

    public void save(Book book) {
        repo.save(book);
    }

    public Book get(Long id) {
        return repo.findById(id).get();
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    public List<Book> sortByIssueDateAsc() {
        return repo.sortByIssueDateAsc();
    }

    public List<Book> sortByIssueDateDesc() {
        return repo.sortByIssueDateDesc();
    }

    public List<Book> getAllBooksInOriginalOrder() {
        return repo.findAllBooksInOrigin();
    }

    public List<Object[]> getBookIssueStatistics() {
        return repo.getBookIssueStatistics();
    }
}