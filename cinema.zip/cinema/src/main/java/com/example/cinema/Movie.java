package com.example.cinema;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Setter
@Getter
public class Movie {
    @Id
    private Long id; // Убираем @GeneratedValue
    private String title; // Название фильма
    private String studio; // Киностудия
    private LocalDateTime dateTime; // Дата и время сеанса
    private int tickets; // Количество билетов на сеанс
}
