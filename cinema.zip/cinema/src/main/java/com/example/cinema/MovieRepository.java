package com.example.cinema;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface MovieRepository extends JpaRepository<Movie, Long> {
    @Query("SELECT m FROM Movie m WHERE CONCAT(m.title, ' ', m.studio) LIKE %?1%")
    List<Movie> search(String keyword);

    @Query("SELECT m FROM Movie m ORDER BY m.dateTime ASC")
    List<Movie> sortByDateTimeAsc();

    @Query("SELECT m FROM Movie m ORDER BY m.dateTime DESC")
    List<Movie> sortByDateTimeDesc();

    @Query("SELECT m FROM Movie m ORDER BY m.id")
    List<Movie> findAllMoviesInOrigin();

    @Query("SELECT m.dateTime, COUNT(m) FROM Movie m GROUP BY m.dateTime")
    List<Object[]> getMovieStatistics();
}
