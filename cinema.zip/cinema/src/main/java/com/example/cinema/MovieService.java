package com.example.cinema;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MovieService {

    @Autowired
    private MovieRepository repo;

    public List<Movie> listAll(String keyword) {
        if (keyword != null) {
            return repo.search(keyword);
        }
        return repo.findAll();
    }

    public void save(Movie movie) {
        repo.save(movie);
    }

    public Movie get(Long id) {
        return repo.findById(id).get();
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    public List<Movie> sortByDateTimeAsc() {
        return repo.sortByDateTimeAsc();
    }

    public List<Movie> sortByDateTimeDesc() {
        return repo.sortByDateTimeDesc();
    }

    public List<Movie> getAllMoviesInOriginalOrder() {
        return repo.findAllMoviesInOrigin();
    }

    public List<Object[]> getMovieStatistics() {
        return repo.getMovieStatistics();
    }
}
