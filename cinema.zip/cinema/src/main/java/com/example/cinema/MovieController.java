package com.example.cinema;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class MovieController {

    @Autowired
    private MovieService service;

    @RequestMapping("/")
    public String viewHomePage(Model model, @RequestParam(value = "keyword", required = false) String keyword) {
        List<Movie> listMovies = service.listAll(keyword);
        model.addAttribute("listMovies", listMovies);
        model.addAttribute("keyword", keyword);

        List<Object[]> stats = service.getMovieStatistics();
        List<String> dates = new ArrayList<>();
        List<Long> counts = new ArrayList<>();

        for (Object[] row : stats) {
            dates.add(row[0].toString());
            counts.add((Long) row[1]);
        }

        model.addAttribute("dates", dates);
        model.addAttribute("counts", counts);

        return "index";  // Возвращаем шаблон
    }

    @RequestMapping("/new")
    public String showNewMovieForm(Model model) {
        Movie movie = new Movie();
        model.addAttribute("movie", movie);
        return "new_movie";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveMovie(@ModelAttribute("movie") Movie movie, BindingResult result) {
        if (result.hasErrors()) {
            return "edit_movie";
        }
        service.save(movie);
        return "redirect:/";
    }

    @RequestMapping("/edit/{id}")
    public String showEditMovieForm(@PathVariable(name = "id") Long id, Model model) {
        Movie movie = service.get(id);
        model.addAttribute("movie", movie);
        return "edit_movie";
    }

    @RequestMapping("/delete/{id}")
    public String deleteMovie(@PathVariable(name = "id") Long id) {
        service.delete(id);
        return "redirect:/";
    }

    @RequestMapping("/sort")
    public String sortByDateTime(@RequestParam(value = "order", defaultValue = "asc") String order, Model model) {
        List<Movie> sortedMovies;

        if (order.equals("asc")) {
            sortedMovies = service.sortByDateTimeAsc();
        } else if (order.equals("desc")) {
            sortedMovies = service.sortByDateTimeDesc();
        } else {
            sortedMovies = service.getAllMoviesInOriginalOrder();
        }
        model.addAttribute("listMovies", sortedMovies);
        model.addAttribute("currentOrder", order);

        List<Object[]> stats = service.getMovieStatistics();
        List<String> dates = new ArrayList<>();
        List<Long> counts = new ArrayList<>();

        for (Object[] row : stats) {
            dates.add(row[0].toString());
            counts.add((Long) row[1]);
        }

        model.addAttribute("dates", dates);
        model.addAttribute("counts", counts);
        return "index";
    }

}
