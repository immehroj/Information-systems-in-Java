package com.example.techwarehouse;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class MachineController {

    @Autowired
    private MachineService service;

    @RequestMapping("/")
    public String viewHomePage(Model model, @RequestParam(value = "keyword", required = false) String keyword) {
        List<Machine> listMachines = service.listAll(keyword);
        model.addAttribute("listMachines", listMachines);
        model.addAttribute("keyword", keyword);

        List<Object[]> stats = service.getMachineStatistics();
        List<String> dates = new ArrayList<>();
        List<Long> counts = new ArrayList<>();

        for (Object[] row : stats) {
            dates.add(row[0].toString());
            counts.add((Long) row[1]);
        }

        model.addAttribute("dates", dates);
        model.addAttribute("counts", counts);

        return "index";
    }

    @RequestMapping("/new")
    public String showNewMachineForm(Model model) {
        Machine machine = new Machine();
        model.addAttribute("machine", machine);
        return "new_machine";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveMachine(@ModelAttribute("machine") Machine machine, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "new_machine";
        }
        if (machine.getDateOut() != null && machine.getDateIn() != null && machine.getDateOut().isBefore(machine.getDateIn())) {
            model.addAttribute("dateError", "Дата вывоза не может быть меньше даты ввоза");
            return "new_machine";
        }
        service.save(machine);
        return "redirect:/";
    }

    @RequestMapping("/edit/{id}")
    public String showEditMachineForm(@PathVariable(name = "id") Long id, Model model) {
        Machine machine = service.get(id);
        model.addAttribute("machine", machine);
        return "edit_machine";
    }

    @RequestMapping("/delete/{id}")
    public String deleteMachine(@PathVariable(name = "id") Long id) {
        service.delete(id);
        return "redirect:/";
    }

    @RequestMapping("/sort")
    public String sortByDateIn(@RequestParam(value = "order", defaultValue = "asc") String order, Model model) {
        List<Machine> sortedMachines;

        if (order.equals("asc")) {
            sortedMachines = service.sortByDateInAsc();
        } else if (order.equals("desc")) {
            sortedMachines = service.sortByDateInDesc();
        } else {
            sortedMachines = service.getAllMachinesInOriginalOrder();
        }
        model.addAttribute("listMachines", sortedMachines);
        model.addAttribute("currentOrder", order);

        List<Object[]> stats = service.getMachineStatistics();
        List<String> dates = new ArrayList<>();
        List<Long> counts = new ArrayList<>();

        for (Object[] row : stats) {
            dates.add(row[0].toString());
            counts.add((Long) row[1]);
        }

        model.addAttribute("dates", dates);
        model.addAttribute("counts", counts);
        return "index";
    }
}


