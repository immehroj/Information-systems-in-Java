package com.example.techwarehouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechwarehouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechwarehouseApplication.class, args);
	}

}
