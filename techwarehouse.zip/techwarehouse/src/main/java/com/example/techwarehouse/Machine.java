package com.example.techwarehouse;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Setter
@Getter
public class Machine {
    @Id
    private Long id;
    private String type;
    private String group1;
    private LocalDate dateIn;
    private LocalDate dateOut;
    private String driverName;
}
