package com.example.techwarehouse;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface MachineRepository extends JpaRepository<Machine, Long> {
    @Query("SELECT m FROM Machine m WHERE CONCAT(m.type, ' ', m.group1, ' ', m.driverName) LIKE %?1%")
    List<Machine> search(String keyword);

    @Query("SELECT m FROM Machine m ORDER BY m.dateIn ASC")
    List<Machine> sortByDateInAsc();

    @Query("SELECT m FROM Machine m ORDER BY m.dateIn DESC")
    List<Machine> sortByDateInDesc();

    @Query("SELECT m FROM Machine m ORDER BY m.id")
    List<Machine> findAllMachinesInOriginalOrder();

    @Query("SELECT m.dateIn, COUNT(m) FROM Machine m GROUP BY m.dateIn")
    List<Object[]> getMachineStatistics();
}
