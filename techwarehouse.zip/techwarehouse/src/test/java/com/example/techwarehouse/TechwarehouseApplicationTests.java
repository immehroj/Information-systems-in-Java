package com.example.techwarehouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechwarehouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
