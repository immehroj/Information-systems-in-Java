package com.example.theater;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface TheatreRepository extends JpaRepository<Theatre, Long> {
    @Query("SELECT p FROM Theatre p WHERE CONCAT(p.id, '', p.play_Name, '', p.acting_Troupe_Name, '', p.play_DateTime, '', p.total_Tickets, '', p.available_Tickets) LIKE %?1%")
    List<Theatre> search(String keyword);

    @Query("SELECT p FROM Theatre p WHERE p.play_DateTime = ?1 ORDER BY p.play_DateTime ASC")
    List<Theatre> findByPlayDateTime(LocalDate playDateTime);
    @Query("SELECT p.play_DateTime, COUNT(p) FROM Theatre p GROUP BY p.play_DateTime")
    List<Object[]> countShowsByDate();
    @Query("SELECT COUNT(p) FROM Theatre p WHERE p.play_DateTime = ?1")
    Long countShowsByDate(LocalDate playDateTime);


}
