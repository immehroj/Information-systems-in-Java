package com.example.theater;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


import java.time.LocalDate;
@Entity
public class Theatre {
    private Long id;
    private String Play_Name;
    private String Acting_Troupe_Name;
    private LocalDate Play_DateTime;
    private Long Total_Tickets;
    private Long Available_Tickets;

    protected Theatre() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPlay_Name() {
        return Play_Name;
    }

    public void setPlay_Name(String Play_Name) {
        this.Play_Name = Play_Name;
    }

    public String getActing_Troupe_Name() {
        return Acting_Troupe_Name;
    }

    public void setActing_Troupe_Name(String Acting_Troupe_Name) {
        this.Acting_Troupe_Name = Acting_Troupe_Name;
    }

    public LocalDate getPlay_DateTime() {
        return Play_DateTime;
    }

    public void setPlay_DateTime(LocalDate Play_DateTime) {
        this.Play_DateTime = Play_DateTime;
    }

    public Long getTotal_Tickets() {
        return Total_Tickets;
    }

    public void setTotal_Tickets(Long Total_Tickets) {
        this.Total_Tickets = Total_Tickets;
    }

    public Long getAvailable_Tickets() {
        return Available_Tickets;
    }

    public void setAvailable_Tickets(Long Available_Tickets) {
        this.Available_Tickets = Available_Tickets;
    }

}




