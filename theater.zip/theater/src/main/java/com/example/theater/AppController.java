package com.example.theater;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {
    @Autowired
    private TheatreService service;

    @RequestMapping("/")
    public String viewHomePage(Model model, @Param("keyword") String keyword) {
        List<Theatre> listTheatres = service.listAll(keyword);
        model.addAttribute("listTheatres", listTheatres);
        model.addAttribute("keyword");
        return "index";
    }

    @RequestMapping("/new")
    public String showNewTheatreForm(Model model) {
        Theatre theatre = new Theatre();
        model.addAttribute("theatre", theatre);
        return "new_theatre";

    }
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveTheatre(@ModelAttribute("theatre") Theatre theatre) {
        service.save(theatre);
        return "redirect:/";
    }
    @RequestMapping("/edit/{id}")
    public ModelAndView showEditTheatreForm(@PathVariable(name = "id") Long id) {
        ModelAndView mav = new ModelAndView("edit_theatre");
        Theatre theatre = service.get(id);
        mav.addObject("theatre", theatre);
        return mav;
    }

    @RequestMapping("/delete/{id}")
    public String deleteTheatre(@PathVariable(name="id") Long id) {
        service.delete(id);
        return "redirect:/";

    }

    @RequestMapping("/searchByDate")
    public String searchByDate(Model model, @Param("playDateTime") String playDateTime) {
        LocalDate date = playDateTime != null ? LocalDate.parse(playDateTime) : null;
        List<Theatre> listTheatres = service.listAllByDate(date);
        model.addAttribute("listTheatres", listTheatres);
        model.addAttribute("playDateTime", playDateTime);
        return "index";
    }
    @RequestMapping("/showsCountByDate")
    @ResponseBody
    public Map<String, Long> getShowsCountByDate() {
        return service.getShowsCountByDate();
    }

    @RequestMapping("/countShowsByDate")
    @ResponseBody
    public Long countShowsByDate(@Param("playDateTime") String playDateTime) {
        LocalDate date = LocalDate.parse(playDateTime);
        return service.countShowsByDate(date);
    }




}