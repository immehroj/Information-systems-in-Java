package com.example.conference;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {
    @Autowired
    private ConferenceService service;

    @RequestMapping("/")
    public String viewHomePage(Model model, @Param("keyword") String keyword) {
        List<Conference> listConferences = service.listAll(keyword);
        model.addAttribute("listConferences", listConferences);
        model.addAttribute("keyword");
        return "index";
    }

    @RequestMapping("/new")
    public String showNewConferenceForm(Model model) {
        Conference conference = new Conference();
        model.addAttribute("conference", conference);
        return "new_conference";

    }
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveTheatre(@ModelAttribute("conference") Conference conference) {
        service.save(conference);
        return "redirect:/";
    }
    @RequestMapping("/edit/{id}")
    public ModelAndView showEditConferenceForm(@PathVariable(name = "id") Long id) {
        ModelAndView mav = new ModelAndView("edit_conference");
        Conference conference = service.get(id);
        mav.addObject("conference", conference);
        return mav;
    }

    @RequestMapping("/delete/{id}")
    public String deleteConference(@PathVariable(name="id") Long id) {
        service.delete(id);
        return "redirect:/";

    }

    @RequestMapping("/searchByDate")
    public String searchByDate(Model model, @Param("conference_date") String conference_date) {
        LocalDate date = conference_date != null ? LocalDate.parse(conference_date) : null;
        List<Conference> listConferences = service.listAllByDate(date);
        model.addAttribute("listConferences", listConferences);
        model.addAttribute("conference_date", conference_date);
        return "index";
    }
    @RequestMapping("/showsCountByDate")
    @ResponseBody
    public Map<String, Long> getShowsCountByDate() {
        return service.getShowsCountByDate();
    }

    @RequestMapping("/countShowsByDate")
    @ResponseBody
    public Long countShowsByDate(@Param("conference_date") String conference_date) {
        LocalDate date = LocalDate.parse(conference_date);
        return service.countShowsByDate(date);
    }

    @RequestMapping("/averageConferencesPerDay")
    @ResponseBody
    public double getAverageConferencesPerDay() {
        return service.calculateAverageConferencesPerDay();

    }





}