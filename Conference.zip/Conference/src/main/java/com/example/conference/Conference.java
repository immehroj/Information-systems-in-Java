package com.example.conference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


import java.time.LocalDate;
@Entity
public class Conference {
    private Long id;
    private String conference_name;
    private LocalDate conference_date;
    private String moderator_name;
    private String keynote_speaker_name;

    protected Conference() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getConference_name() {
        return conference_name;
    }
    public void setConference_name(String conference_name) {
        this.conference_name = conference_name;
    }
    public LocalDate getConference_date() {
        return conference_date;
    }
    public void setConference_date(LocalDate conference_date) {
        this.conference_date = conference_date;
    }
    public String getModerator_name() {
        return moderator_name;
    }
    public void setModerator_name(String moderator_name) {
        this.moderator_name = moderator_name;
    }
    public String getKeynote_speaker_name() {
        return keynote_speaker_name;
    }
    public void setKeynote_speaker_name(String keynote_speaker_name) {
        this.keynote_speaker_name = keynote_speaker_name;
    }




}