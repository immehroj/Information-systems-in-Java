package com.example.conference;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConferenceService {
    @Autowired
    private ConferenceRepository repo;

    public List<Conference> listAll(String keyword) {
        if (keyword != null) {
            return repo.search(keyword);
        }
        return repo.findAll();
    }

    public void save(Conference conference) {
        repo.save(conference);
    }

    public Conference get(Long id) {
        return repo.findById(id).get();
    }

    public void delete(Long id) {
        repo.deleteById(id);

    }

    public List<Conference> listAllByDate(LocalDate conference_date) {
        return repo.findByconference_date(conference_date);
    }
    public Map<String, Long> getShowsCountByDate() {
        List<Object[]> results = repo.countShowsByDate();
        Map<String, Long> showsCountByDate = new HashMap<>();
        for (Object[] result : results) {
            LocalDate date = (LocalDate) result[0];
            Long count = (Long) result[1];
            showsCountByDate.put(date.toString(), count);
        }
        return showsCountByDate;
    }

    public Long countShowsByDate(LocalDate conference_date) {
        return repo.countShowsByDate(conference_date);
    }
    public double calculateAverageConferencesPerDay() {
        List<Object[]> results = repo.countConferencesByDate();
        long totalClients = 0;
        int totalDays = results.size();

        for (Object[] result : results) {
            long count = (Long) result[1];
            totalClients += count;
        }

        return totalDays == 0 ? 0 : (double) totalClients / totalDays;
    }




}

