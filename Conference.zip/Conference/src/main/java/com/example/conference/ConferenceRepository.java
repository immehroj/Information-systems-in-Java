package com.example.conference;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ConferenceRepository extends JpaRepository<Conference, Long> {
    @Query("SELECT p FROM Conference p WHERE CONCAT(p.id, '', p.conference_name, '', p.conference_date, '', p.moderator_name, '', p.keynote_speaker_name) LIKE %?1%")
    List<Conference> search(String keyword);
    @Query("SELECT p FROM Conference p WHERE p.conference_date = ?1 ORDER BY p.conference_date ASC")
    List<Conference> findByconference_date(LocalDate conference_date);
    @Query("SELECT p.conference_date, COUNT(p) FROM Conference p GROUP BY p.conference_date")
    List<Object[]> countShowsByDate();
    @Query("SELECT COUNT(p) FROM Conference p WHERE p.conference_date = ?1")
    Long countShowsByDate(LocalDate conference_date);
    @Query("SELECT p.conference_date, COUNT(p) FROM Conference p GROUP BY p.conference_date")
    List<Object[]> countConferencesByDate();



}

