package com.example.projj;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class CarController {

    @Autowired
    private CarService service;

    @RequestMapping("/")
    public String viewHomePage(Model model, @RequestParam(value = "keyword", required = false) String keyword) {
        List<Car> listCars = service.listAll(keyword);
        model.addAttribute("listCars", listCars);
        model.addAttribute("keyword", keyword);

        List<Object[]> stats = service.getCarDeliveryStatistics();
        List<String> dates = new ArrayList<>();
        List<Long> counts = new ArrayList<>();

        for (Object[] row : stats) {
            dates.add(row[0].toString());
            counts.add((Long) row[1]);
        }

        model.addAttribute("dates", dates);
        model.addAttribute("counts", counts);

        return "index";  // Возвращаем шаблон
    }

    @RequestMapping("/new")
    public String showNewCarForm(Model model) {
        Car car = new Car();
        model.addAttribute("car", car);
        return "new_car";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveCar(@ModelAttribute("car") Car car, BindingResult result) {
        if (result.hasErrors()) {
            return "edit_car";
        }
        service.save(car);
        return "redirect:/";
    }

    @RequestMapping("/edit/{id}")
    public String showEditCarForm(@PathVariable(name = "id") Long id, Model model) {
        Car car = service.get(id);
        model.addAttribute("car", car);
        return "edit_car";
    }

    @RequestMapping("/delete/{id}")
    public String deleteCar(@PathVariable(name = "id") Long id) {
        service.delete(id);
        return "redirect:/";
    }

    @RequestMapping("/sort")
    public String sortByDateOfDelivery(@RequestParam(value = "order", defaultValue = "asc") String order, Model model) {
        List<Car> sortedcars;

        if (order.equals("asc")) {
            sortedcars = service.sortByDateOfDeliveryAsc();
        } else if (order.equals("desc")) {
            sortedcars = service.sortByDateOfDeliveryDesc();
        } else {
            sortedcars = service.getAllCarsInOriginalOrder();
        }
        model.addAttribute("listCars", sortedcars);
        model.addAttribute("currentOrder", order);

        List<Object[]> stats = service.getCarDeliveryStatistics();
        List<String> dates = new ArrayList<>();
        List<Long> counts = new ArrayList<>();

        for (Object[] row : stats) {
            dates.add(row[0].toString());
            counts.add((Long) row[1]);
        }

        model.addAttribute("dates", dates);
        model.addAttribute("counts", counts);
        return "index";
    }

}