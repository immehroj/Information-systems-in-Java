package com.example.projj;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CarRepository extends JpaRepository<Car, Long> {
    @Query("SELECT c FROM Car c WHERE concat(c.brand, ' ', c.ownerName) LIKE %?1%")
    List<Car> search(String keyword);

    @Query("SELECT c FROM Car c ORDER BY c.dateOfDelivery ASC")
    List<Car> sortByDateOfDeliveryAsc();

    @Query("SELECT c FROM Car c ORDER BY c.dateOfDelivery DESC")
    List<Car> sortByDateOfDeliveryDesc();

    @Query("SELECT c FROM Car c ORDER BY c.id")
    List<Car> findAllCarsInOrigin();

    @Query("SELECT c.dateOfDelivery, COUNT(c) FROM Car c GROUP BY c.dateOfDelivery")
    List<Object[]> getCarDeliveryStatistics();
}
