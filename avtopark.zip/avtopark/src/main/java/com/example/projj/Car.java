package com.example.projj;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Setter
@Getter
public class Car {
    @Id
    private Long id; // Убираем @GeneratedValue
    private String brand;
    private int yearOfManufacture;
    private LocalDate dateOfDelivery;
    private String ownerName;
}
