package com.example.Cargo;

// JpaRepository – это интерфейс фреймворка Spring Data предоставляющий набор стандартных методов JPA для работы с БД.
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
// JpaRepository – это интерфейс фреймворка Spring Data предоставляющий набор стандартных методов JPA для работы с БД.
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

// Repository – указывает, что класс используется для задания перечня необходимых работ по поиску, получению и сохранению данных.
@Repository
// Метод поиска по ключевому слову, который ищет совпадения в полях названия груза, содержимого, города отправки и города прибытия.
public interface CargoRepository extends JpaRepository<Cargo, Long> {
    @Query("SELECT c FROM Cargo c WHERE concat(c.cargo_name, ' ', c.cargo_content,' ',c.cargo_city, ' ',c.arrival_city) LIKE %?1%")
    List<Cargo> search(String keyword);

    @Query("SELECT c FROM Cargo c ORDER BY c.arrival_date ASC")
    List<Cargo> sortByDateOfDeliveryAsc();

    @Query("SELECT c FROM Cargo c ORDER BY c.arrival_date DESC")
    List<Cargo> sortByDateOfDeliveryDesc();

    @Query("SELECT c FROM Cargo c ORDER BY c.id")
    List<Cargo> findAllCarsInOrigin();

    @Query("SELECT c.arrival_date, COUNT(c) FROM Cargo c GROUP BY c.arrival_date")
    List<Object[]> getCargoDeliveryStatistics();
}
// %?1% означает, что мы ищем любое вхождение ключевого слова (?1) в строки полей. Символы % указывают, что ключевое слово может находиться в любом месте строки
