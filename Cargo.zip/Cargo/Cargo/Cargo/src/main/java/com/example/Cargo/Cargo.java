package com.example.Cargo;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue; // аннотация для работы со столбцами в скл, id указывается автоматически
import jakarta.persistence.GenerationType; // класс отвечающих за тип данных перечисление
import jakarta.persistence.Id; // указание на первичный ключ
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity //аннотация, укзание на то что класс является сущностью и относится к orm jpa
public class Cargo {
    private Long id;
    @Getter
    private String cargo_name;
    @Getter
    private String cargo_content;
    @Getter
    private String cargo_city;
    @Getter
    private LocalDate shipping_date;
    @Getter
    private String arrival_city;
    @Getter
    private LocalDate arrival_date;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long getId() {
        return id;
    }
}