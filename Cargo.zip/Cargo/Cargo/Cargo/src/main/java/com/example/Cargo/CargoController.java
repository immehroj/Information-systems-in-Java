package com.example.Cargo;

// Контроллер - это класс, предназначенный для непосредственной обработки запросов от клиента и возвращения результатов.
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CargoController {

    @Autowired
    private CargoService service;

    @RequestMapping("/")
    // Аннотация @RequestMapping используется для мапинга (связывания) с URL для всего класса или для конкретного метода обработчика.
    public String index(Model model, @Param("keyword") String keyword) {
        // Получение всех грузов по ключевому слову (если оно задано) и добавление их в модель
        List<com.example.Cargo.Cargo> listCargos = service.listAll(keyword); // Добавление списка грузов в модель
        model.addAttribute("listCargos", listCargos); // Добавление ключевого слова для отображения
        model.addAttribute("keyword", keyword);

        // Получение статистики по доставке грузов (например, количество грузов по датам)
        List<Object[]> stats = service.getCargoDeliveryStatistics();
        List<String> dates = new ArrayList<>();
        List<Long> counts = new ArrayList<>();

        for (Object[] row : stats) {
            dates.add(row[0].toString());
            counts.add((Long) row[1]);
        }

        model.addAttribute("dates", dates);
        model.addAttribute("counts", counts);

        return "index";  // Возвращаем шаблон
    }

    @RequestMapping("/new")
    public String showNewCargoForm(Model model) {
        com.example.Cargo.Cargo cargo = new com.example.Cargo.Cargo();
        model.addAttribute("cargo", cargo);
        return "new_cargo";
    }

    @RequestMapping(value = "/save")
    public String saveCargo(@ModelAttribute("cargo") com.example.Cargo.Cargo cargo, BindingResult result) {
        if (result.hasErrors()) {
            return "edit_cargo";
        }
        service.save(cargo);
        return "redirect:/";
    }

    @RequestMapping("/edit/{id}")
    public String showEditCargoForm(@PathVariable(name = "id") Long id, Model model) {
        com.example.Cargo.Cargo cargo = service.get(id);
        model.addAttribute("cargo", cargo);
        return "edit_cargo";
    }

    @RequestMapping("/delete/{id}")
    public String deleteCar(@PathVariable(name = "id") Long id) {
        service.delete(id);
        return "redirect:/";
    }

    @RequestMapping("/sort")
    public String sortByArrival_date(@RequestParam(value = "order", defaultValue = "asc") String order, Model model) {
        List<com.example.Cargo.Cargo> sortedcargos;
        // Выполнение сортировки в зависимости от параметра "order"
        if (order.equals("asc")) {
            sortedcargos = service.sortByArrival_dateAsc(); // Сортировка по возрастанию
        } else if (order.equals("desc")) {
            sortedcargos = service.sortByArrival_dateDesc(); // Сортировка по убыванию
        } else {
            sortedcargos = service.getAllCargosInOriginalOrder(); // Если порядок не задан, возвращаем оригинальный список
        }
        model.addAttribute("listCargos", sortedcargos);
        model.addAttribute("currentOrder", order);

        List<Object[]> stats = service.getCargoDeliveryStatistics();
        List<String> dates = new ArrayList<>();
        List<Long> counts = new ArrayList<>();

        for (Object[] row : stats) {
            dates.add(row[0].toString());
            counts.add((Long) row[1]);
        }

        model.addAttribute("dates", dates);
        model.addAttribute("counts", counts);
        return "index";
    }


}
