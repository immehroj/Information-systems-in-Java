package com.example.Cargo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;  // связь всех зависимостей
import org.springframework.stereotype.Service;
// Service – указывает, что класс является сервисом для реализации бизнес логики.
@Service
public class CargoService {

    @Autowired
    private CargoRepository repo;
    // Внедрение репозитория CargoRepository для взаимодействия с базой данных через методы.
    //Внедрение репозитория, который обрабатывает взаимодействие с базой данных. С помощью @Autowired Spring автоматически создает экземпляр этого класса.

    public List<Cargo> listAll(String keyword) {
        if (keyword != null) {
            return repo.search(keyword);
        }
        return repo.findAll();
    }

    public void save(Cargo cargo) {
        repo.save(cargo);
    }

    public Cargo get(Long id) {
        return repo.findById(id).get();
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    public List<Cargo> sortByArrival_dateAsc() {
        return repo.sortByDateOfDeliveryAsc();
    }

    public List<Cargo> sortByArrival_dateDesc() {
        return repo.sortByDateOfDeliveryDesc();
    }

    public List<Cargo> getAllCargosInOriginalOrder() {
        return repo.findAllCarsInOrigin();
    }

    public List<Object[]> getCargoDeliveryStatistics() {
        return repo.getCargoDeliveryStatistics();
    }
}
