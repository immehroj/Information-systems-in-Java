

@Autowired(required = false)
private MyService myService;

@Autowired
@Qualifier("specificService")
private MyService myService;

