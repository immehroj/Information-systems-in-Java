package com.example.barbershop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarbershopApplicationTests {

    @Test
    void contextLoads() {
    }

}
