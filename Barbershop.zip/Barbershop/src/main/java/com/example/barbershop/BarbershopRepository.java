package com.example.barbershop;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface BarbershopRepository extends JpaRepository<Barbershop, Long> {
    @Query("SELECT p FROM Barbershop p WHERE CONCAT(p.id, '', p.full_name, '', p.appointment_date, '', p.service, '', p.barber) LIKE %?1%")
    List<Barbershop> search(String keyword);

    @Query("SELECT p FROM Barbershop p WHERE p.appointment_date = ?1 ORDER BY p.appointment_date ASC")
    List<Barbershop> findByappointment_date(LocalDate appointment_date);
    @Query("SELECT p.appointment_date, COUNT(p) FROM Barbershop p GROUP BY p.appointment_date")
    List<Object[]> countShowsByDate();
    @Query("SELECT COUNT(p) FROM Barbershop p WHERE p.appointment_date = ?1")
    Long countShowsByDate(LocalDate appointment_date);
    @Query("SELECT p.appointment_date, COUNT(p) FROM Barbershop p GROUP BY p.appointment_date")
    List<Object[]> countClientsByDate();

}
