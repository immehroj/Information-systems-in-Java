package com.example.barbershop;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {
    @Autowired
    private BarbershopService service;

    @RequestMapping("/")
    public String viewHomePage(Model model, @Param("keyword") String keyword) {
        List<Barbershop> listBarbershops = service.listAll(keyword);
        model.addAttribute("listBarbershops", listBarbershops);
        model.addAttribute("keyword");
        return "index";
    }

    @RequestMapping("/new")
    public String showNewBarbershopForm(Model model) {
        Barbershop barbershop = new Barbershop();
        model.addAttribute("barbershop", barbershop);
        return "new_barbershop";

    }
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveBarbershop(@ModelAttribute("barbershop") Barbershop barbershop) {
        service.save(barbershop);
        return "redirect:/";
    }
    @RequestMapping("/edit/{id}")
    public ModelAndView showEditBarbershopForm(@PathVariable(name = "id") Long id) {
        ModelAndView mav = new ModelAndView("edit_barbershop");
        Barbershop barbershop = service.get(id);
        mav.addObject("barbershop", barbershop);
        return mav;
    }

    @RequestMapping("/delete/{id}")
    public String deleteBarbershop(@PathVariable(name="id") Long id) {
        service.delete(id);
        return "redirect:/";

    }

    @RequestMapping("/searchByDate")
    public String searchByDate(Model model, @Param("appointment_date") String appointment_date) {
        LocalDate date = appointment_date != null ? LocalDate.parse(appointment_date) : null;
        List<Barbershop> listBarbershops = service.listAllByDate(date);
        model.addAttribute("listBarbershops", listBarbershops);
        model.addAttribute("appointment_date", appointment_date);
        return "index";
    }
    @RequestMapping("/showsCountByDate")
    @ResponseBody
    public Map<String, Long> getShowsCountByDate() {
        return service.getShowsCountByDate();
    }

    @RequestMapping("/countShowsByDate")
    @ResponseBody
    public Long countShowsByDate(@Param("appointment_date") String appointment_date) {
        LocalDate date = LocalDate.parse(appointment_date);
        return service.countShowsByDate(date);
    }
    @RequestMapping("/averageClientsPerDay")
    @ResponseBody
    public double getAverageClientsPerDay() {
        return service.calculateAverageClientsPerDay();


    }

}
